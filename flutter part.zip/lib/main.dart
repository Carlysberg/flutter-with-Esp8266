import 'package:flutter/material.dart';
import 'package:jay_c/screens/homeass.dart';

void main() {
  runApp(const MyApp());
}
